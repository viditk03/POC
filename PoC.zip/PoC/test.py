import pandas as pd
import random
from faker import Faker

fake = Faker()
Faker.seed(42)
random.seed(42)

# All districts in Rajasthan
districts = [
    'Ajmer', 'Alwar', 'Banswara', 'Baran', 'Barmer', 'Bharatpur', 'Bhilwara',
    'Bikaner', 'Bundi', 'Chittorgarh', 'Churu', 'Dausa', 'Dholpur', 'Dungarpur',
    'Hanumangarh', 'Jaipur', 'Jaisalmer', 'Jalore', 'Jhalawar', 'Jhunjhunu',
    'Jodhpur', 'Karauli', 'Kota', 'Nagaur', 'Pali', 'Pratapgarh', 'Rajsamand',
    'Sawai Madhopur', 'Sikar', 'Sirohi', 'Sri Ganganagar', 'Tonk', 'Udaipur'
]

# Simplified options for categorical data
genders = ['Male', 'Female', 'Other']
categories = ['SC', 'ST', 'OBC', 'General']
relationship = ['Stranger', 'Relative', 'Neighbor', 'Acquaintance']
yes_no = ['Yes', 'No']
case_statuses = ['Open', 'Closed', 'Chargesheeted', 'Final Report']
final_reports = ['Closure', 'Charge-sheet', 'Summary Report']
bail_statuses = ['In Custody', 'Released on Bail']

# Generate synthetic dataset
rows = []
for _ in range(1000):
    row = {
        "District": random.choice(districts),
        "FIR Content": fake.text(100),
        "Crime Description": fake.sentence(),
        "Date/Time of Occurrence": fake.date_time_this_decade(),
        "Is Time Known": random.choice(yes_no),
        "Victim Type": random.choice(["Individual", "Organization"]),
        "Victim Age": random.randint(10, 80),
        "Victim Gender": random.choice(genders),
        "Victim Category": random.choice(categories),
        "Accused Known/Unknown": random.choice(["Known", "Unknown"]),
        "Accused Juvenile": random.choice(yes_no),
        "Accused Gender": random.choice(genders),
        "Accused Category": random.choice(categories),
        "Relation to Victim": random.choice(relationship),
        "Complainant Gender": random.choice(genders),
        "Complainant Relation": random.choice(relationship),
        "Police Station": f"{random.choice(districts)} PS",
        "Refused Investigation": random.choice(yes_no),
        "Distance from PS": round(random.uniform(0.5, 50), 2),
        "IPC Sections": random.choice(["302", "376", "420", "498A", "323"]),
        "Major Head": random.choice(["Murder", "Theft", "Fraud"]),
        "Minor Head": random.choice(["Attempted", "Completed", "Conspiracy"]),
        "Prior FIR Count": random.randint(0, 5),
        "Convictions": random.randint(0, 3),
        "Bail Jump": random.choice(yes_no),
        "Known Criminal": random.choice(yes_no),
        "Crime Location": fake.address(),
        "Arrest Status": random.choice(yes_no),
        "FIR Refused": random.choice(yes_no),
        "Ongoing Investigations": random.randint(0, 3),
        "Gang Affiliation": random.choice(yes_no),
        "Addiction Flag": random.choice(yes_no),
        "Living Status": random.choice(["Alive", "Dead"]),
        "Is Recidivist": random.choice(yes_no),
        "Method of Entry": random.choice(["Forced Entry", "Unforced", "Unknown"]),
        "Property Type Involved": random.choice(["Electronics", "Jewelry", "Cash"]),
        "Property Recovery Status": random.choice(yes_no),
        "Suspect Age": random.randint(18, 65),
        "Suspect Gender": random.choice(genders),
        "Suspect Profession": random.choice(["Laborer", "Engineer", "Unemployed"]),
        "Number of Accused": random.randint(1, 5),
        "Vehicle Used": random.choice(["Bike", "Car", "None"]),
        "FIR Year": random.randint(2015, 2024),
        "Case Status": random.choice(case_statuses),
        "IO Name / Rank": fake.name(),
        "Reason for Delay": fake.sentence(),
        "Witness Count": random.randint(0, 5),
        "Property Recovered": random.choice(yes_no),
        "Arrest Date": fake.date_this_decade(),
        "Time to Investigation Start (days)": random.randint(0, 30),
        "Medical Examination": random.choice(yes_no),
        "Previous Criminal History": random.choice(yes_no),
        "Property Recovery / Seizure": random.choice(yes_no),
        "Chargesheet Filed": random.choice(yes_no),
        "Final Report Type": random.choice(final_reports),
        "Court Name / Jurisdiction": f"{random.choice(districts)} Court",
        "Court Case Outcome": random.choice(["Convicted", "Acquitted", "Ongoing"]),
        "Case Duration (days)": random.randint(10, 1000),
        "Legal Representation Provided": random.choice(["Private", "Public Defender"]),
        "Bail Status": random.choice(bail_statuses),
        "Investigation Officer Rank": random.choice(["SI", "Inspector", "DSP"]),
        "Delay in Reporting (days)": random.randint(0, 60),
        "Evidence Tendered": random.randint(0, 10),
        "Witness Details": fake.sentence()
    }
    rows.append(row)

df = pd.DataFrame(rows)

# Save to Excel
output_path = "data/rajasthan_crime_1000rows.xlsx"
df.to_excel(output_path, index=False)

output_path
