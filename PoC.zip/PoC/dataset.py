import csv

# Sample Malayalam and English medical phrases
malayalam_phrases = [
    "തുടർച്ചയായ complaints of ചുമ.",
    "കീമോതെറാപ്പി undergoing chemotherapy.",
    "ഛർദ്ദിയും abdominal pain and വയറുവേദനയും.",
    "Left radius പൊട്ടൽ.",
    "ശ്വാസതടസ്സം experiencing shortness of breath.",
    "How long have you had ഈ ലക്ഷണങ്ങൾ?",
    "Do you have a history of ഹൃദ്രോഗം in your family?",
    "മൂത്രവിസർജ്ജനം indicates presence of ketones.",
    "Pain relief വേണ്ടി ibuprofen 400 മില്ലിഗ്രാം നൽകുക.",
    "Asthma condition വേണ്ടി ആൽബുടെറോൾ inhaler prescribe ചെയ്തു.",
    "പൂർണ്ണമായ രക്തസംഖ്യ shows elevated white blood cell count.",
    "പനിയും body aches കൂടി അനുഭവപ്പെടുന്നു.",
]

english_phrases = [
    "Complains of persistent cough.",
    "Undergoing chemotherapy.",
    "Vomiting and abdominal cramps.",
    "Fracture of the left radius.",
    "Experiencing shortness of breath.",
    "How long have you had these symptoms?",
    "Do you have a history of heart disease in your family?",
    "Urinalysis indicates presence of ketones.",
    "Administered ibuprofen 400 mg for pain.",
    "Prescribed albuterol inhaler for asthma.",
    "Complete blood count shows elevated white blood cell count.",
    "Fever with body aches.",
]

# Function to generate dataset
def generate_dataset(rows=10000, output_file="malayalam_english_mixed_dataset.csv"):
    with open(output_file, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        # Write header
        writer.writerow(["Malayalam-English Mixed Sentence", "English Translation"])
        for i in range(rows):
            # Generate a random sentence from the lists
            malayalam = malayalam_phrases[i % len(malayalam_phrases)]
            english = english_phrases[i % len(english_phrases)]
            # Write row
            writer.writerow([malayalam, english])
    print(f"Dataset with {rows} rows has been generated and saved to {output_file}.")

# Generate 10,000 rows dataset
generate_dataset(rows=10000)