import gradio as gr
import speech_recognition as sr
from pydub import AudioSegment
import os
import tempfile

# Convert any audio format to WAV using pydub
def convert_audio_to_wav(file_path):
    audio = AudioSegment.from_file(file_path)
    wav_path = tempfile.mktemp(suffix=".wav")
    audio.export(wav_path, format="wav")
    return wav_path

# Transcribe Malayalam audio
def transcribe_malayalam(audio_file):
    try:
        wav_path = convert_audio_to_wav(audio_file)
        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_path) as source:
            audio_data = recognizer.record(source)

        text = recognizer.recognize_google(audio_data, language="ml-IN")
        return text
    except sr.UnknownValueError:
        return "⚠️ Could not understand the audio."
    except sr.RequestError as e:
        return f"❌ Google API Error: {e}"
    except Exception as e:
        return f"❌ Error: {str(e)}"

# Gradio interface
interface = gr.Interface(
    fn=transcribe_malayalam,
    inputs=gr.Audio(type="filepath", label="Upload Malayalam Audio"),
    outputs=gr.Textbox(label="Transcribed Malayalam Text"),
    title="Malayalam Speech-to-Text",
    description="Upload a Malayalam audio file (MP3, OPUS, etc.) and get the transcription."
)

if __name__ == "__main__":
    interface.launch()
