import gradio as gr
import tensorflow_hub as hub
import speech_recognition as sr

# Replace with a model that supports Malayalam if needed
model_url = "https://tfhub.dev/google/translate_en_to_fr/1"  # Example model URL for English to French translation

try:
    model = hub.load(model_url)
    print("Model loaded successfully!")
except Exception as e:
    print(f"Error loading model: {e}")

def transcribe_and_translate(audio_file):
    # Step 1: Transcribe the audio file to text using SpeechRecognition
    recognizer = sr.Recognizer()
    
    # Open the audio file for transcription
    with sr.AudioFile(audio_file) as source:
        audio = recognizer.record(source)
    
    try:
        transcription = recognizer.recognize_google(audio)
        print(f"Transcription: {transcription}")
    except sr.UnknownValueError:
        transcription = "Audio could not be understood."
    except sr.RequestError as e:
        transcription = f"Could not request results; {e}"

    # Step 2: Translate the transcription (example: English to French)
    if transcription != "Audio could not be understood.":
        try:
            translation = model.signatures['serving_default'](
                tf.constant([transcription])
            )['outputs'].numpy()[0].decode('utf-8')
            return transcription, translation
        except Exception as e:
            return transcription, f"Error in translation: {e}"

    return transcription, "Translation failed."

# Gradio interface
interface = gr.Interface(
    fn=transcribe_and_translate,
    inputs=gr.Audio(type="filepath", label="Upload Audio"),  # Use filepath type to handle file paths
    outputs=[
        gr.Textbox(label="Transcription (English)"),
        gr.Textbox(label="Translation (Target Language)"),
    ],
    title="Audio Transcription and Translation (T2T-like with TensorFlow)",
    description="Upload an audio file. The app will transcribe it to English and translate to the target language (e.g., French or Malayalam)."
)

interface.launch()
